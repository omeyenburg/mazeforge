"""MazeForge

Contact:
--------

- oskar.meyenburg@gmail.com

More information is available at:

- https://pypi.org/project/mazeforge/
- https://github.com/oskarmeyenburg/mazeforge
"""
from .generator import generate


__version__ = "0.1.0"